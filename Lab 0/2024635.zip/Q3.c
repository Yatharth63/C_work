#include <stdio.h>

int main() 
{
    int n;

    
    printf("Enter the number of elements: ");
    scanf("%d", &n);

    int arr[n];

    printf("Enter %d integers: ", n);
    for (int i = 0; i < n; i++) 
    {
        scanf("%d", &arr[i]);
    }
    int hark[n];
    for (int r = 0; r < n; r++)
    {
        hark[r]=0;
    }
    for (int r = 0; r < n; r++)
    {
        for (int u= 0; u < n; u++)
        {
            if(arr[r]==arr[u]) 
            {
                hark[r]+=1;
            }
        }
    }
    for (int r = 0; r < n; r++)
    {
        if(hark[r] > n/2)
        {
            printf("%d ", arr[r]);
            return 0;

        }
    }
    printf("-1");
    return 0;

}