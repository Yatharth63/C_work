#include <stdio.h>

unsigned long long fac(int n) {
    unsigned long long finaly = 1; 
    for (int i = 1; i <= n; i++) {
        finaly *= i; 
    }

    return finaly;
}

int main()
{
    int number;
    printf("enter a number:");
    scanf("%d", &number);

    if (number < 0) 
    {
        printf("Factorial is not defined for negative numbers.\n");
    } 
    else 
    {
        printf("Factorial of %d is: %llu\n", number, fac(number));
    }


    return 0;
}